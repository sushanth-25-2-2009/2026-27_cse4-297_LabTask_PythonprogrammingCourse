PYTHON PROGRAMMING LAB SOLUTIONS - UNITS I TO IV

Total Python solution files: 111
Each task is saved in its own .py file using the faculty-provided filename.
Folders: Unit-1, Unit-2, Unit-3, Unit-4.

How to use:
1. Extract this ZIP file.
2. Open the Python_Programming_lab folder in VS Code.
3. Open a task .py file and run it with Python.
4. Unit-4 file-handling programs may need sample.txt in the same working folder.

Note: These are beginner-friendly reference solutions. Read, run and understand
each program, and adjust examples/input handling to match your faculty's hints.
