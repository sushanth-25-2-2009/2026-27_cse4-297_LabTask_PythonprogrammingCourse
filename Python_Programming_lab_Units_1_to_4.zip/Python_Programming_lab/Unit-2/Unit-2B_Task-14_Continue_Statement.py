print("Skip 5 using for loop:")
for i in range(1, 11):
    if i == 5:
        continue
    print(i)
print("Skip 5 using while loop:")
i = 1
while i <= 10:
    if i == 5:
        i += 1
        continue
    print(i)
    i += 1
