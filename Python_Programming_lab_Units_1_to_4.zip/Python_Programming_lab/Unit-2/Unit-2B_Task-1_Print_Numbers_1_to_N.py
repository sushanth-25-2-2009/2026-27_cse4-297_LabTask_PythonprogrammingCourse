n = int(input("Enter N: "))
print("Using for loop:")
for i in range(1, n + 1):
    print(i, end=" ")
print("\nUsing while loop:")
i = 1
while i <= n:
    print(i, end=" ")
    i += 1
print()
