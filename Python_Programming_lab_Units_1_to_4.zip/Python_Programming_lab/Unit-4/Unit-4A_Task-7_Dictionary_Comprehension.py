squares = {n: n * n for n in range(1, 11)}
print("Number and square dictionary:", squares)
